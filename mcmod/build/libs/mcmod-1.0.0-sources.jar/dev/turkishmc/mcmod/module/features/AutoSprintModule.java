package dev.turkishmc.mcmod.module.features;

import dev.turkishmc.mcmod.module.Module;
import net.minecraft.class_310;

public final class AutoSprintModule extends Module {
	public AutoSprintModule() {
		super("auto_sprint", "Auto Sprint", "Uygun olduğunda otomatik koşar.", Category.UTILITY);
	}

	@Override
	protected void tick(class_310 client) {
		if (client.field_1724 != null && !client.field_1724.method_5715() && !client.field_1724.method_5765()) {
			client.field_1724.method_5728(true);
		}
	}
}
