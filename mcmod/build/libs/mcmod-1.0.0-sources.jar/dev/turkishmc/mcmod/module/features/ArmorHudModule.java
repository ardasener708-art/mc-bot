package dev.turkishmc.mcmod.module.features;

import dev.turkishmc.mcmod.module.Module;
import dev.turkishmc.mcmod.render.HudOverlay;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ArmorHudModule extends Module {
	public ArmorHudModule() {
		super("armor_hud", "Armor HUD", "Zırh ve eldeki eşyaların dayanıklılığını gösterir.", Category.HUD);
	}

	@Override
	protected void drawHud(class_310 client, class_332 graphics) {
		HudOverlay.drawArmor(graphics, client);
	}
}
