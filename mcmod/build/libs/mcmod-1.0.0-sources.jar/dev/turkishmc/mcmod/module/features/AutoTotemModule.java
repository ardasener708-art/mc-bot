package dev.turkishmc.mcmod.module.features;

import dev.turkishmc.mcmod.module.Module;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class AutoTotemModule extends Module {
	public AutoTotemModule() {
		super("auto_totem", "Auto Totem", "Yan elde totem yoksa envanterden otomatik taşır.", Category.UTILITY);
	}

	@Override
	protected void tick(class_310 client) {
		if (client.field_1724 == null || client.field_1761 == null
				|| client.field_1724.field_7512 != client.field_1724.field_7498
				|| !client.field_1724.field_7512.method_34255().method_7960()
				|| client.field_1724.method_6079().method_31574(class_1802.field_8288)) {
			return;
		}

		var menu = client.field_1724.field_7498;
		for (int slot = 9; slot < 45; slot++) {
			if (slot == 45 || !menu.method_7611(slot).method_7677().method_31574(class_1802.field_8288)) {
				continue;
			}
			client.field_1761.method_2906(menu.field_7763, slot, 0, class_1713.field_7790, client.field_1724);
			client.field_1761.method_2906(menu.field_7763, 45, 0, class_1713.field_7790, client.field_1724);
			client.field_1761.method_2906(menu.field_7763, slot, 0, class_1713.field_7790, client.field_1724);
			return;
		}
	}
}
