package dev.turkishmc.mcmod.module.features;

import dev.turkishmc.mcmod.module.Module;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public final class ZoomModule extends Module {
	private boolean zooming;
	private int previousFov = 70;

	public ZoomModule() {
		super("zoom", "Zoom", "C tuşunu basılı tutarak yakınlaştırır.", Category.VISUAL);
		setKeyCode(GLFW.GLFW_KEY_C);
		addIntegerSetting("fov", "Yakınlaştırma FOV", 30, 20, 70, 5);
	}

	@Override
	public void onKeybind(boolean down, boolean pressed, class_310 client) {
		boolean shouldZoom = isEnabled() && down;
		if (shouldZoom && !zooming) {
			previousFov = client.field_1690.method_41808().method_41753();
			zooming = true;
		}
		if (shouldZoom) {
			client.field_1690.method_41808().method_41748(getSetting("fov").getInt());
		} else if (zooming) {
			client.field_1690.method_41808().method_41748(previousFov);
			zooming = false;
		}
	}

	@Override
	protected void onToggled(boolean enabled) {
		if (!enabled && zooming) {
			class_310 client = class_310.method_1551();
			client.field_1690.method_41808().method_41748(previousFov);
			zooming = false;
		}
	}
}
