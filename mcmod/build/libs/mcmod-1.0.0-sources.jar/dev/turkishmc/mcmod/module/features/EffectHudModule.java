package dev.turkishmc.mcmod.module.features;

import dev.turkishmc.mcmod.module.Module;
import dev.turkishmc.mcmod.render.HudOverlay;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class EffectHudModule extends Module {
	public EffectHudModule() {
		super("effect_hud", "Efekt HUD", "Aktif iksir efektlerini ve sürelerini listeler.", Category.HUD);
		addColorSetting("color", "Vurgu rengi", 0x59D5C5);
	}

	@Override
	protected void drawHud(class_310 client, class_332 graphics) {
		HudOverlay.drawEffects(graphics, client, getSetting("color").getInt());
	}
}
