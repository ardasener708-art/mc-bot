package dev.turkishmc.mcmod.module.features;

import dev.turkishmc.mcmod.module.Module;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class AutoToolModule extends Module {
	public AutoToolModule() {
		super("auto_tool", "Auto Tool", "Hedeflenen blok için en etkili hotbar aletini seçer.", Category.UTILITY);
	}

	@Override
	protected void tick(class_310 client) {
		if (client.field_1724 == null || !client.field_1690.field_1886.method_1434()
				|| !(client.field_1765 instanceof class_3965 hit)) {
			return;
		}

		var state = client.field_1687.method_8320(hit.method_17777());
		int bestSlot = client.field_1724.method_31548().method_67532();
		float bestSpeed = client.field_1724.method_6047().method_7924(state);

		for (int slot = 0; slot < 9; slot++) {
			class_1799 stack = client.field_1724.method_31548().method_5438(slot);
			float speed = stack.method_7924(state);
			if (speed > bestSpeed) {
				bestSpeed = speed;
				bestSlot = slot;
			}
		}
		client.field_1724.method_31548().method_61496(bestSlot);
	}
}
