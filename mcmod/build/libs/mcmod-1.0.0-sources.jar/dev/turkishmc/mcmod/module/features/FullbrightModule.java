package dev.turkishmc.mcmod.module.features;

import dev.turkishmc.mcmod.module.Module;
import net.minecraft.class_310;

public final class FullbrightModule extends Module {
	private double previousGamma = 1.0;

	public FullbrightModule() {
		super("fullbright", "Fullbright", "Karanlık alanları tam aydınlık gösterir.", Category.VISUAL);
	}

	@Override
	protected void onToggled(boolean enabled) {
		class_310 client = class_310.method_1551();
		if (enabled) {
			previousGamma = client.field_1690.method_42473().method_41753();
			client.field_1690.method_42473().method_41748(100.0);
		} else {
			client.field_1690.method_42473().method_41748(previousGamma);
		}
	}

	@Override
	protected void tick(class_310 client) {
		if (client.field_1690.method_42473().method_41753() < 100.0) {
			client.field_1690.method_42473().method_41748(100.0);
		}
	}
}
