package dev.turkishmc.mcmod.module.features;

import dev.turkishmc.mcmod.module.Module;
import dev.turkishmc.mcmod.render.HudOverlay;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class KeystrokesModule extends Module {
	public KeystrokesModule() {
		super("keystrokes", "Keystrokes", "WASD ve fare tıklamalarını ekranda gösterir.", Category.HUD);
	}

	@Override
	protected void drawHud(class_310 client, class_332 graphics) {
		HudOverlay.drawKeystrokes(graphics, client);
	}
}
