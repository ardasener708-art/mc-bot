package dev.turkishmc.mcmod.module.features;

import dev.turkishmc.mcmod.module.Module;
import dev.turkishmc.mcmod.render.HudOverlay;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ActiveModulesModule extends Module {
	public ActiveModulesModule() {
		super("active_modules", "Aktif Modüller", "Açık modülleri ekranın köşesinde listeler.", Category.HUD);
	}

	@Override
	protected void drawHud(class_310 client, class_332 graphics) {
		HudOverlay.drawActiveModules(graphics);
	}
}
