package dev.turkishmc.mcmod.render;

import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import dev.turkishmc.mcmod.McModClient;
import dev.turkishmc.mcmod.module.Module;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12247;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public final class EspRenderer {
	private static final RenderPipeline ESP_PIPELINE = createEspPipeline();
	private static final class_1921 ESP_LINES = class_1921.method_75940(
			"mcmod_entity_esp",
			class_12247.method_75927(ESP_PIPELINE)
					.method_75930(class_12245.field_63976)
					.method_75938()
	);

	private static volatile List<BoxSnapshot> boxes = List.of();
	private static volatile List<BoxSnapshot> chestBoxes = List.of();
	private static volatile List<LineSnapshot> tracers = List.of();
	private static volatile List<TagSnapshot> nameTags = List.of();
	private static class_638 chestScanWorld;
	private static long lastChestScanTick = Long.MIN_VALUE;
	private static List<class_2338> cachedChestPositions = List.of();

	private EspRenderer() {
	}

	private static RenderPipeline createEspPipeline() {
		RenderPipeline pipeline = RenderPipeline.builder(class_10799.field_56859)
				.withLocation("pipeline/entity_esp")
				.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
				.withDepthWrite(false)
				.build();
		class_10799.method_67887(pipeline);
		return pipeline;
	}

	public static void extract(WorldExtractionContext context) {
		Module esp = McModClient.MODULES.getModule(McModClient.ESP_MODULE_NAME);
		Module tracerModule = McModClient.MODULES.getModule("tracers");
		Module chestModule = McModClient.MODULES.getModule("chest_esp");
		Module nametagModule = McModClient.MODULES.getModule("nametags");

		class_310 client = class_310.method_1551();
		class_243 cameraPosition = context.camera().method_71156();
		List<BoxSnapshot> extractedBoxes = new ArrayList<>();
		List<BoxSnapshot> extractedChestBoxes = new ArrayList<>();
		List<LineSnapshot> extractedTracers = new ArrayList<>();
		List<TagSnapshot> extractedNameTags = new ArrayList<>();

		for (class_1297 entity : context.world().method_18112()) {
			if (entity == client.field_1724 || entity.method_31481()) {
				continue;
			}

			class_238 bounds = entity.method_5829().method_989(
					-cameraPosition.field_1352,
					-cameraPosition.field_1351,
					-cameraPosition.field_1350
			);
			if (esp.isEnabled()) {
				int color = colorFor(entity);
				if (color != 0) {
					extractedBoxes.add(new BoxSnapshot(bounds, color));
				}
			}
			if (tracerModule.isEnabled() && entity.method_73189().method_1022(cameraPosition)
					<= tracerModule.getSetting("range").getInt()) {
				int color = 0xFF000000 | tracerModule.getSetting("color").getInt();
				extractedTracers.add(new LineSnapshot(
						bounds.method_1005().field_1352, bounds.method_1005().field_1351, bounds.method_1005().field_1350, color));
			}
			if (nametagModule.isEnabled() && entity instanceof class_1309 living
					&& entity.method_73189().method_1022(cameraPosition)
					<= nametagModule.getSetting("range").getInt()) {
				String label = living.method_5476().getString() + "  "
						+ String.format("%.0f❤  %.0fm", living.method_6032(),
						entity.method_73189().method_1022(cameraPosition));
				extractedNameTags.add(new TagSnapshot(bounds.method_1005().field_1352,
						bounds.field_1325 + 0.25, bounds.method_1005().field_1350, label));
			}
		}

		if (chestModule.isEnabled()) {
			int range = chestModule.getSetting("range").getInt();
			int color = 0xFF000000 | chestModule.getSetting("color").getInt();
			class_638 world = context.world();
			long gameTime = world.method_75260();
			if (world != chestScanWorld || gameTime - lastChestScanTick >= 10) {
				cachedChestPositions = scanNearbyChests(world, class_2338.method_49638(cameraPosition), range);
				chestScanWorld = world;
				lastChestScanTick = gameTime;
			}
			for (class_2338 pos : cachedChestPositions) {
				if (pos.method_19770(cameraPosition) > (double) range * range) {
					continue;
				}
				class_238 bounds = new class_238(pos).method_989(-cameraPosition.field_1352, -cameraPosition.field_1351, -cameraPosition.field_1350);
				extractedChestBoxes.add(new BoxSnapshot(bounds, color));
			}
		}

		boxes = List.copyOf(extractedBoxes);
		chestBoxes = List.copyOf(extractedChestBoxes);
		tracers = List.copyOf(extractedTracers);
		nameTags = List.copyOf(extractedNameTags);
		for (Module module : McModClient.MODULES.getModules()) {
			module.extractWorld(context);
		}
	}

	private static List<class_2338> scanNearbyChests(class_638 world, class_2338 center, int range) {
		int verticalRange = Math.min(range, 6);
		List<class_2338> positions = new ArrayList<>();
		class_2338.class_2339 cursor = new class_2338.class_2339();
		for (int x = center.method_10263() - range; x <= center.method_10263() + range; x++) {
			for (int z = center.method_10260() - range; z <= center.method_10260() + range; z++) {
				if (!world.method_8393(Math.floorDiv(x, 16), Math.floorDiv(z, 16))) {
					continue;
				}
				for (int y = Math.max(world.method_31607(), center.method_10264() - verticalRange);
					 y <= Math.min(world.method_31600(), center.method_10264() + verticalRange); y++) {
					cursor.method_10103(x, y, z);
					var block = world.method_8320(cursor).method_26204();
					if (block == class_2246.field_10034 || block == class_2246.field_10380 || block == class_2246.field_16328
							|| block instanceof class_2480) {
						positions.add(cursor.method_10062());
					}
				}
			}
		}
		return List.copyOf(positions);
	}

	public static void render(WorldRenderContext context) {
		if (boxes.isEmpty() && chestBoxes.isEmpty() && tracers.isEmpty() && nameTags.isEmpty()) {
			for (Module module : McModClient.MODULES.getModules()) {
				module.renderWorld(context);
			}
			return;
		}

		class_4597 consumers = context.consumers();
		if (consumers == null) {
			return;
		}

		// 1.21.11'in yeni render yolunda context matrisi null olabilir.
		class_4587 matrices = context.matrices();
		if (matrices == null) {
			matrices = new class_4587();
		}
		Matrix4f matrix = matrices.method_23760().method_23761();
		class_4588 vertices = consumers.method_73477(ESP_LINES);

		for (BoxSnapshot box : boxes) {
			drawBox(vertices, matrix, box.bounds(), box.color());
		}
		for (BoxSnapshot box : chestBoxes) {
			drawBox(vertices, matrix, box.bounds(), box.color());
		}
		for (LineSnapshot tracer : tracers) {
			line(vertices, matrix, 0, 0, 0, tracer.x(), tracer.y(), tracer.z(),
					((tracer.color() >>> 16) & 0xFF) / 255.0F,
					((tracer.color() >>> 8) & 0xFF) / 255.0F,
					(tracer.color() & 0xFF) / 255.0F,
					((tracer.color() >>> 24) & 0xFF) / 255.0F);
		}
		if (!nameTags.isEmpty()) {
			class_310 client = class_310.method_1551();
			float scale = McModClient.MODULES.getModule("nametags").getSetting("scale").getInt() / 1000.0F;
			for (TagSnapshot tag : nameTags) {
				matrices.method_22903();
				matrices.method_22904(tag.x(), tag.y(), tag.z());
				matrices.method_22907(client.field_1773.method_19418().method_23767());
				matrices.method_22905(-scale, -scale, scale);
				client.field_1772.method_27521(tag.label(), -client.field_1772.method_1727(tag.label()) / 2.0F, 0,
						0xFFFFFFFF, false, matrices.method_23760().method_23761(), consumers,
						net.minecraft.class_327.class_6415.field_33993, 0x90000000, 15728880);
				matrices.method_22909();
			}
		}
		for (Module module : McModClient.MODULES.getModules()) {
			module.renderWorld(context);
		}
	}

	private static int colorFor(class_1297 entity) {
		if (entity instanceof class_1657) {
			return colorSetting("color");
		}
		if (entity instanceof class_1569) {
			return colorSetting("hostile_color");
		}
		if (entity instanceof class_1308) {
			return colorSetting("passive_color");
		}
		return 0;
	}

	private static int colorSetting(String setting) {
		return 0xFF000000 | McModClient.MODULES.getModule(McModClient.ESP_MODULE_NAME)
				.getSetting(setting).getInt();
	}

	private static void drawBox(class_4588 vertices, Matrix4f matrix, class_238 box, int color) {
		float red = ((color >>> 16) & 0xFF) / 255.0F;
		float green = ((color >>> 8) & 0xFF) / 255.0F;
		float blue = (color & 0xFF) / 255.0F;
		float alpha = ((color >>> 24) & 0xFF) / 255.0F;

		double x0 = box.field_1323;
		double y0 = box.field_1322;
		double z0 = box.field_1321;
		double x1 = box.field_1320;
		double y1 = box.field_1325;
		double z1 = box.field_1324;

		line(vertices, matrix, x0, y0, z0, x1, y0, z0, red, green, blue, alpha);
		line(vertices, matrix, x1, y0, z0, x1, y0, z1, red, green, blue, alpha);
		line(vertices, matrix, x1, y0, z1, x0, y0, z1, red, green, blue, alpha);
		line(vertices, matrix, x0, y0, z1, x0, y0, z0, red, green, blue, alpha);

		line(vertices, matrix, x0, y1, z0, x1, y1, z0, red, green, blue, alpha);
		line(vertices, matrix, x1, y1, z0, x1, y1, z1, red, green, blue, alpha);
		line(vertices, matrix, x1, y1, z1, x0, y1, z1, red, green, blue, alpha);
		line(vertices, matrix, x0, y1, z1, x0, y1, z0, red, green, blue, alpha);

		line(vertices, matrix, x0, y0, z0, x0, y1, z0, red, green, blue, alpha);
		line(vertices, matrix, x1, y0, z0, x1, y1, z0, red, green, blue, alpha);
		line(vertices, matrix, x1, y0, z1, x1, y1, z1, red, green, blue, alpha);
		line(vertices, matrix, x0, y0, z1, x0, y1, z1, red, green, blue, alpha);
	}

	private static void line(
			class_4588 vertices,
			Matrix4f matrix,
			double x0,
			double y0,
			double z0,
			double x1,
			double y1,
			double z1,
			float red,
			float green,
			float blue,
			float alpha
	) {
		vertices.method_22918(matrix, (float) x0, (float) y0, (float) z0)
				.method_22915(red, green, blue, alpha)
				.method_22914(0.0F, 1.0F, 0.0F)
				.method_75298(2.0F);
		vertices.method_22918(matrix, (float) x1, (float) y1, (float) z1)
				.method_22915(red, green, blue, alpha)
				.method_22914(0.0F, 1.0F, 0.0F)
				.method_75298(2.0F);
	}

	private record BoxSnapshot(class_238 bounds, int color) {
	}

	private record LineSnapshot(double x, double y, double z, int color) {
	}

	private record TagSnapshot(double x, double y, double z, String label) {
	}
}
