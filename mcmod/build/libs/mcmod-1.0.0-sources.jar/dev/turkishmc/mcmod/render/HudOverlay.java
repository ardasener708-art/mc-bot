package dev.turkishmc.mcmod.render;

import dev.turkishmc.mcmod.McModClient;
import dev.turkishmc.mcmod.module.Module;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class HudOverlay {
	private static final int PANEL = 0xB9101824;
	private static final int ACCENT = 0xFF59D5C5;
	private static final int TEXT = 0xFFF0F5FA;
	private static final int MUTED = 0xFF8293A5;

	private HudOverlay() {
	}

	public static void register() {
		HudElementRegistry.addLast(class_2960.method_60655("mcmod", "client_hud"), HudOverlay::render);
	}

	private static void render(class_332 graphics, net.minecraft.class_9779 tickCounter) {
		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || client.field_1690.field_1842) {
			return;
		}

		for (Module module : McModClient.MODULES.getModules()) {
			module.renderHud(client, graphics);
		}
	}

	public static void drawInfo(class_332 graphics, class_310 client) {
		int x = 8;
		int y = 8;
		int width = 126;
		graphics.method_25294(x, y, x + width, y + 45, PANEL);
		graphics.method_25294(x, y, x + 2, y + 45, ACCENT);
		String coordinates = String.format("X %.1f  Y %.1f  Z %.1f",
				client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
		var info = client.method_1562() == null ? null
				: client.method_1562().method_2871(client.field_1724.method_5667());
		String ping = info == null ? "--" : info.method_2959() + " ms";
		graphics.method_25303(client.field_1772, "FPS  " + client.method_47599() + "    PING  " + ping,
				x + 8, y + 8, TEXT);
		graphics.method_25303(client.field_1772, coordinates, x + 8, y + 26, MUTED);
	}

	public static void drawArmor(class_332 graphics, class_310 client) {
		List<class_1799> items = new ArrayList<>();
		for (class_1304 slot : List.of(class_1304.field_6169, class_1304.field_6174,
				class_1304.field_6172, class_1304.field_6166)) {
			class_1799 stack = client.field_1724.method_6118(slot);
			if (!stack.method_7960()) {
				items.add(stack);
			}
		}
		if (!client.field_1724.method_6047().method_7960()) {
			items.add(client.field_1724.method_6047());
		}
		if (!client.field_1724.method_6079().method_7960()) {
			items.add(client.field_1724.method_6079());
		}

		int startX = (graphics.method_51421() - items.size() * 24) / 2;
		int y = graphics.method_51443() - 78;
		for (int i = 0; i < items.size(); i++) {
			class_1799 stack = items.get(i);
			int x = startX + i * 24;
			graphics.method_25294(x, y, x + 22, y + 34, PANEL);
			graphics.method_51427(stack, x + 3, y + 2);
			if (stack.method_7963()) {
				int remaining = Math.max(0, stack.method_7936() - stack.method_7919());
				float ratio = (float) remaining / stack.method_7936();
				int color = ratio > 0.5F ? 0xFF55DD88 : ratio > 0.2F ? 0xFFFFC857 : 0xFFFF5C6C;
				graphics.method_25300(client.field_1772, Integer.toString(remaining),
						x + 11, y + 23, color);
			}
		}
	}

	public static void drawKeystrokes(class_332 graphics, class_310 client) {
		int x = 8;
		int y = graphics.method_51443() - 72;
		drawKey(graphics, client, x + 24, y, GLFW.GLFW_KEY_W, "W");
		drawKey(graphics, client, x, y + 23, GLFW.GLFW_KEY_A, "A");
		drawKey(graphics, client, x + 24, y + 23, GLFW.GLFW_KEY_S, "S");
		drawKey(graphics, client, x + 48, y + 23, GLFW.GLFW_KEY_D, "D");
		drawMouse(graphics, client, x, y + 46, GLFW.GLFW_MOUSE_BUTTON_LEFT, "L");
		drawMouse(graphics, client, x + 26, y + 46, GLFW.GLFW_MOUSE_BUTTON_RIGHT, "R");
	}

	private static void drawKey(class_332 graphics, class_310 client, int x, int y, int code, String label) {
		boolean pressed = GLFW.glfwGetKey(client.method_22683().method_4490(), code) == GLFW.GLFW_PRESS;
		drawKeyBox(graphics, x, y, label, pressed);
	}

	private static void drawMouse(class_332 graphics, class_310 client, int x, int y, int button, String label) {
		boolean pressed = GLFW.glfwGetMouseButton(client.method_22683().method_4490(), button) == GLFW.GLFW_PRESS;
		drawKeyBox(graphics, x, y, label, pressed);
	}

	private static void drawKeyBox(class_332 graphics, int x, int y, String label, boolean pressed) {
		graphics.method_25294(x, y, x + 22, y + 20, pressed ? 0xFF14534E : PANEL);
		graphics.method_25300(class_310.method_1551().field_1772, label, x + 11, y + 6,
				pressed ? ACCENT : TEXT);
	}

	public static void drawActiveModules(class_332 graphics) {
		List<Module> active = McModClient.MODULES.getModules().stream()
				.filter(Module::isEnabled)
				.toList();
		int y = 10;
		for (Module module : active) {
			String label = module.getName();
			int textWidth = class_310.method_1551().field_1772.method_1727(label);
			int x = graphics.method_51421() - textWidth - 20;
			graphics.method_25294(x - 6, y - 3, graphics.method_51421() - 8, y + 12, PANEL);
			graphics.method_25294(graphics.method_51421() - 10, y - 3, graphics.method_51421() - 8, y + 12, ACCENT);
			graphics.method_25303(class_310.method_1551().field_1772, label, x, y, TEXT);
			y += 18;
		}
	}

	public static void drawEffects(class_332 graphics, class_310 client, int color) {
		List<String> effects = client.field_1724.method_6026().stream()
				.map(effect -> effect.method_5579().comp_349().method_5560().getString()
						+ " " + (effect.method_5578() + 1) + "  " + formatDuration(effect.method_5584()))
				.toList();
		if (effects.isEmpty()) {
			return;
		}

		int width = 142;
		int x = graphics.method_51421() - width - 8;
		int y = graphics.method_51443() - 12 - effects.size() * 15;
		graphics.method_25294(x, y, x + width, y + effects.size() * 15 + 6, PANEL);
		graphics.method_25294(x, y, x + 2, y + effects.size() * 15 + 6, 0xFF000000 | color);
		for (int i = 0; i < effects.size(); i++) {
			String label = effects.get(i);
			if (client.field_1772.method_1727(label) > width - 12) {
				label = client.field_1772.method_27523(label, width - 16);
			}
			graphics.method_25303(client.field_1772, label, x + 8, y + 4 + i * 15, TEXT);
		}
	}

	public static void drawDirection(class_332 graphics, class_310 client, int color) {
		String[] directions = {"G", "GB", "B", "KB", "K", "KD", "D", "GD"};
		int index = Math.floorMod(Math.round(client.field_1724.method_36454() / 45.0F), directions.length);
		String direction = directions[index];
		int centerX = graphics.method_51421() / 2;
		graphics.method_25294(centerX - 28, 8, centerX + 28, 29, PANEL);
		graphics.method_25294(centerX - 28, 8, centerX + 28, 10, 0xFF000000 | color);
		graphics.method_25300(client.field_1772, direction, centerX, 15, 0xFF000000 | color);
	}

	private static String formatDuration(int ticks) {
		if (ticks < 0) {
			return "∞";
		}
		int seconds = ticks / 20;
		return String.format("%d:%02d", seconds / 60, seconds % 60);
	}

}
