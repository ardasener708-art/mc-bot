package dev.turkishmc.mcmod.gui;

import dev.turkishmc.mcmod.config.ModConfig;
import dev.turkishmc.mcmod.module.Module;
import dev.turkishmc.mcmod.module.ModuleManager;
import dev.turkishmc.mcmod.module.ModuleSetting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;

public final class ModuleScreen extends class_437 {
	private static final int PANEL = 0xFF101824;
	private static final int PANEL_LIGHT = 0xFF172331;
	private static final int BORDER = 0xFF263746;
	private static final int TEXT = 0xFFF0F5FA;
	private static final int MUTED = 0xFF8293A5;
	private static final int ACCENT = 0xFF59D5C5;

	private final ModuleManager moduleManager;
	private Module.Category selectedCategory = Module.Category.VISUAL;
	private Module selectedModule;
	private class_342 searchBox;
	private int panelX;
	private int panelY;
	private int panelWidth;
	private int panelHeight;
	private int sidebarWidth;
	private int scrollOffset;
	private boolean waitingForKey;

	public ModuleScreen(ModuleManager moduleManager) {
		super(class_2561.method_43470("McMod"));
		this.moduleManager = moduleManager;
	}

	@Override
	protected void method_25426() {
		panelWidth = Math.min(500, field_22789 - 24);
		panelHeight = Math.min(340, field_22790 - 24);
		panelX = (field_22789 - panelWidth) / 2;
		panelY = (field_22790 - panelHeight) / 2;
		sidebarWidth = Math.min(104, panelWidth / 3);

		searchBox = new class_342(field_22793, panelX + sidebarWidth + 18, panelY + 68,
				Math.max(80, panelWidth - sidebarWidth - 36), 20, class_2561.method_43470("Ara"));
		searchBox.method_47404(class_2561.method_43470("Modül ara..."));
		searchBox.method_1880(40);
		method_37063(searchBox);
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
		graphics.method_25294(0, 0, field_22789, field_22790, 0x99050A11);
		graphics.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, PANEL);
		graphics.method_25294(panelX, panelY, panelX + sidebarWidth, panelY + panelHeight, 0xFF0C131D);
		graphics.method_25294(panelX + sidebarWidth, panelY, panelX + sidebarWidth + 2, panelY + panelHeight, BORDER);

		drawSidebar(graphics);
		if (selectedModule == null) {
			drawModuleList(graphics, mouseX, mouseY);
		} else {
			drawSettings(graphics, mouseX, mouseY);
		}
		super.method_25394(graphics, mouseX, mouseY, delta);
	}

	private void drawSidebar(class_332 graphics) {
		graphics.method_25294(panelX, panelY, panelX + sidebarWidth, panelY + 3, ACCENT);
		graphics.method_25294(panelX + 16, panelY + 18, panelX + 43, panelY + 45, 0xFF18333A);
		graphics.method_25300(field_22793, "M", panelX + 29, panelY + 27, ACCENT);
		graphics.method_25303(field_22793, "MC MOD", panelX + 16, panelY + 54, TEXT);
		graphics.method_25303(field_22793, "CLIENT", panelX + 16, panelY + 68, MUTED);
		graphics.method_25303(field_22793, "MODÜLLER", panelX + 14, panelY + 98, MUTED);

		int categoryY = panelY + 113;
		for (Module.Category category : Module.Category.values()) {
			boolean selected = selectedCategory == category;
			if (selected) {
				graphics.method_25294(panelX + 8, categoryY - 5, panelX + sidebarWidth - 8, categoryY + 17, 0xFF172A35);
				graphics.method_25294(panelX + 8, categoryY - 5, panelX + 10, categoryY + 17, ACCENT);
			}
			graphics.method_25303(field_22793, category.getTitle(), panelX + 18, categoryY + 2,
					selected ? TEXT : MUTED);
			categoryY += 27;
		}

		graphics.method_25294(panelX + 12, panelY + panelHeight - 39,
				panelX + sidebarWidth - 12, panelY + panelHeight - 38, BORDER);
		graphics.method_25303(field_22793, "FABRIC 1.21.11", panelX + 14, panelY + panelHeight - 27, MUTED);
	}

	private void drawModuleList(class_332 graphics, int mouseX, int mouseY) {
		int contentX = panelX + sidebarWidth + 18;
		int contentRight = panelX + panelWidth - 16;
		graphics.method_25303(field_22793, selectedCategory.getTitle().toUpperCase(), contentX, panelY + 17, ACCENT);
		graphics.method_25303(field_22793, "Özellikler", contentX, panelY + 34, TEXT);
		graphics.method_25303(field_22793, "Bir karta sağ tıklayarak ayarları aç.", contentX, panelY + 51, MUTED);

		List<Module> visible = filteredModules();
		int firstY = panelY + 96;
		int cardHeight = 48;
		int gap = 7;
		int maxVisible = Math.max(1, (panelY + panelHeight - 31 - firstY) / (cardHeight + gap));
		scrollOffset = Math.min(scrollOffset, Math.max(0, visible.size() - maxVisible));
		int end = Math.min(visible.size(), scrollOffset + maxVisible);

		for (int index = scrollOffset; index < end; index++) {
			Module module = visible.get(index);
			int rowY = firstY + (index - scrollOffset) * (cardHeight + gap);
			graphics.method_25294(contentX, rowY, contentRight, rowY + cardHeight, PANEL_LIGHT);
			graphics.method_25294(contentX, rowY, contentX + 2, rowY + cardHeight,
					module.isEnabled() ? ACCENT : BORDER);
			graphics.method_25303(field_22793, module.getName(), contentX + 11, rowY + 7, TEXT);
			graphics.method_25303(field_22793, trim(module.getDescription(), 40), contentX + 11, rowY + 25, MUTED);

			int toggleWidth = 58;
			int toggleX = contentRight - toggleWidth - 9;
			graphics.method_25294(toggleX, rowY + 13, toggleX + toggleWidth, rowY + 35,
					module.isEnabled() ? 0xFF14534E : 0xFF293541);
			graphics.method_25300(field_22793, module.isEnabled() ? "AÇIK" : "KAPALI",
					toggleX + toggleWidth / 2, rowY + 20, module.isEnabled() ? ACCENT : MUTED);
		}

		String count = visible.isEmpty() ? "Sonuç yok" : (scrollOffset + 1) + "-" + end + " / " + visible.size();
		graphics.method_25303(field_22793, count + "  ·  Sağ Shift: kapat", contentX, panelY + panelHeight - 20, MUTED);
	}

	private void drawSettings(class_332 graphics, int mouseX, int mouseY) {
		int contentX = panelX + sidebarWidth + 18;
		int contentRight = panelX + panelWidth - 16;
		graphics.method_25303(field_22793, "<  GERİ", contentX, panelY + 17, ACCENT);
		graphics.method_25303(field_22793, selectedModule.getName(), contentX, panelY + 38, TEXT);
		graphics.method_25303(field_22793, trim(selectedModule.getDescription(), 48), contentX, panelY + 55, MUTED);

		int y = panelY + 83;
		for (ModuleSetting setting : selectedModule.getSettings()) {
			graphics.method_25294(contentX, y, contentRight, y + 27, PANEL_LIGHT);
			graphics.method_25303(field_22793, setting.getLabel(), contentX + 8, y + 9, TEXT);
			if (setting.getType() == ModuleSetting.Type.COLOR) {
				graphics.method_25294(contentRight - 94, y + 7, contentRight - 82, y + 20,
						0xFF000000 | setting.getInt());
			}
			graphics.method_25303(field_22793, setting.getDisplayValue(), contentRight - 76, y + 9, ACCENT);
			y += 31;
		}

		graphics.method_25303(field_22793, "Tuş: " + keyName(selectedModule.getKeyCode())
						+ (waitingForKey ? "  (tuşa bas)" : "  ·  Tuş atamak için buraya tıkla"),
				contentX, panelY + panelHeight - 34, waitingForKey ? ACCENT : MUTED);
		graphics.method_25303(field_22793, "Ayarı değiştirmek için tıkla  ·  Sağ tık: geri",
				contentX, panelY + panelHeight - 20, MUTED);
	}

	private List<Module> filteredModules() {
		String query = searchBox == null ? "" : searchBox.method_1882().trim().toLowerCase();
		List<Module> result = new ArrayList<>();
		for (Module module : moduleManager.getModules(selectedCategory)) {
			if (query.isEmpty() || module.getName().toLowerCase().contains(query)
					|| module.getDescription().toLowerCase().contains(query)) {
				result.add(module);
			}
		}
		return result;
	}

	@Override
	public boolean method_25402(class_11909 event, boolean doubled) {
		if (super.method_25402(event, doubled)) {
			return true;
		}

		double mouseX = event.comp_4798();
		double mouseY = event.comp_4799();
		if (mouseX >= panelX && mouseX < panelX + sidebarWidth
				&& mouseY >= panelY + 108 && mouseY < panelY + 108 + Module.Category.values().length * 27) {
			int categoryIndex = (int) (mouseY - (panelY + 108)) / 27;
			selectedCategory = Module.Category.values()[categoryIndex];
			selectedModule = null;
			scrollOffset = 0;
			return true;
		}

		int contentX = panelX + sidebarWidth + 18;
		int contentRight = panelX + panelWidth - 16;
		if (selectedModule != null) {
			int settingY = panelY + 83;
			for (ModuleSetting setting : selectedModule.getSettings()) {
				if ((event.method_74245() == 0 || event.method_74245() == 1)
						&& mouseX >= contentX && mouseX < contentRight
						&& mouseY >= settingY && mouseY < settingY + 27) {
					setting.adjust(event.method_74245() == 0);
					ModConfig.save(moduleManager);
					return true;
				}
				settingY += 31;
			}

			if (event.method_74245() == 1 || (mouseX >= contentX && mouseX < contentX + 48
					&& mouseY >= panelY + 10 && mouseY <= panelY + 30)) {
				selectedModule = null;
				waitingForKey = false;
				searchBox.method_1862(true);
				return true;
			}

			if (mouseX >= contentX && mouseX < contentRight
					&& mouseY >= panelY + panelHeight - 46) {
				waitingForKey = true;
				return true;
			}

			return true;
		}

		if (mouseX >= contentX && mouseX < contentRight && mouseY >= panelY + 96) {
			List<Module> visible = filteredModules();
			int row = (int) (mouseY - (panelY + 96)) / 55;
			int index = scrollOffset + row;
			int rowY = panelY + 96 + row * 55;
			if (row >= 0 && index < visible.size() && mouseY < rowY + 48) {
				Module module = visible.get(index);
				if (event.method_74245() == 1) {
					selectedModule = module;
					searchBox.method_1862(false);
				} else if (mouseX >= contentRight - 72) {
					module.toggle();
					ModConfig.save(moduleManager);
				}
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean method_25404(class_11908 event) {
		if (waitingForKey && selectedModule != null) {
			selectedModule.setKeyCode(event.comp_4795() == GLFW.GLFW_KEY_ESCAPE ? -1 : event.comp_4795());
			waitingForKey = false;
			ModConfig.save(moduleManager);
			return true;
		}
		return super.method_25404(event);
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		if (selectedModule == null && mouseX >= panelX + sidebarWidth && mouseX < panelX + panelWidth) {
			int visibleCount = filteredModules().size();
			int maxVisible = Math.max(1,
					(panelHeight - 31 - 96) / (48 + 7));
			scrollOffset = Math.max(0, Math.min(visibleCount - maxVisible,
					scrollOffset + (verticalAmount < 0 ? 1 : -1)));
			return true;
		}
		return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
	}

	private static String keyName(int keyCode) {
		return keyCode < 0 ? "Yok" : GLFW.glfwGetKeyName(keyCode, 0) == null
				? "Klavye " + keyCode : GLFW.glfwGetKeyName(keyCode, 0).toUpperCase();
	}

	private static String trim(String value, int maxLength) {
		return value.length() <= maxLength ? value : value.substring(0, maxLength - 1) + "...";
	}
}
